#ifndef VFM_EXT_H
#define VFM_EXT_H

extern int vfm_map_add(char *id, char *name_chain);

extern int vfm_map_remove(char *id);

#endif /* VFM_EXT_H */

