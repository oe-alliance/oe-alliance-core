
#ifndef _VFD_H_
#define _VFD_H_

#include <string>
#include "ft.h"
#include "upng.h"

class VFD
{
protected:
	int m_fd;
public:
	VFD();
	~VFD();
};

class textVFD:public VFD
{
public:
	textVFD();
	~textVFD();
	int textUpdate(const std::string &in);
	std::string replace_all(const std::string &text, const std::string &s, const std::string &f);
};

class graphicVFD:public VFD
{
private:
	unsigned char *m_dest;
	int m_xres;
	int m_yres;
	int m_bpp;
	FreeType m_ft;
	uPNG m_png;
	
public:
	graphicVFD(int xres, int yres, int bpp);
	~graphicVFD();
	int displayText(const char* text, const char* fontFile, int fontSize, int posX, int posY);
	void Write(void);

//	void showBuffer(void);
	int displayPNG(const char* filepath, int posX, int posY);
};

#endif