
#include <stdio.h>
#include <unistd.h>
#include "upng.h"

gSurface::gSurface(int width, int height, int _bpp)
{
	x = width;
	y = height;
	bpp = _bpp;

	switch (bpp)
	{
	case 8:
		bypp = 1;
		break;
	case 15:
	case 16:
		bypp = 2;
		break;
	case 24:		// never use 24bit mode
	case 32:
		bypp = 4;
		break;
	default:
		bypp = (bpp+7)/8;
	}

	stride = x*bypp;
	
	data = 0;

	clut.colors = 0;
	clut.data = 0;

	if (!data)
		data = new unsigned char [y * stride];
}

gSurface::~gSurface()
{
	if (data)
	{
		delete [] (unsigned char*)data;
	}
	if(clut.data)
	{
		delete [] clut.data;
	}
}

uPNG::uPNG()
{
	m_surface = NULL;
}
uPNG::~uPNG()
{
	if(m_surface != NULL)
		delete m_surface;
}

gSurface* uPNG::loadPNG(const char* filename)
{
	unsigned char header[8];
	FILE *fp=fopen(filename, "rb");
	
	if (!fp)
	{
		printf("[PNG LOAD FAILED] couldn't open %s\n", filename );
		return NULL;
	}
	if (!fread(header, 8, 1, fp))
	{
		printf("[PNG LOAD FAILED] couldn't read\n");
		fclose(fp);
		return NULL;
	}
	if (png_sig_cmp(header, 0, 8))
	{
		fclose(fp);
		return NULL;
	}
	png_structp png_ptr=png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);
	if (!png_ptr)
	{
		printf("[PNG LOAD FAILED] no pngptr\n");
		fclose(fp);
		return NULL;
	}
	png_infop info_ptr=png_create_info_struct(png_ptr);
	if (!info_ptr)
	{
		printf("[PNG LOAD FAILED] no info ptr\n");
		png_destroy_read_struct(&png_ptr, (png_infopp)0, (png_infopp)0);
		fclose(fp);
		return NULL;
	}
	png_infop end_info = png_create_info_struct(png_ptr);
	if (!end_info)
	{
		printf("[PNG LOAD FAILED] no end\n");
		png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
		fclose(fp);
		return NULL;
	 }
	if (setjmp(png_jmpbuf(png_ptr)))
	{
		printf("[PNG LOAD FAILED] that was probably nothing\n");
		png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
		fclose(fp);
		return NULL;
	}
	png_init_io(png_ptr, fp);
	png_set_sig_bytes(png_ptr, 8);
	png_set_invert_alpha(png_ptr);
	png_read_info(png_ptr, info_ptr);
	
	png_uint_32 width, height;
	int bit_depth;
	int color_type;
	
	png_get_IHDR(png_ptr, info_ptr, &width, &height, &bit_depth, &color_type, 0, 0, 0);


	gSurface* surface;
	if (color_type == PNG_COLOR_TYPE_GRAY || color_type & PNG_COLOR_MASK_PALETTE)
	{
		surface = new gSurface(width, height, bit_depth);
		png_bytep *rowptr=new png_bytep[height];
	
		for (unsigned int i=0; i<height; i++)
			rowptr[i]=((png_byte*)(surface->data))+i*surface->stride;
		png_read_rows(png_ptr, rowptr, 0, height);
	
		delete [] rowptr;
	
		if (png_get_valid(png_ptr, info_ptr, PNG_INFO_PLTE))
		{
			png_color *palette;
			int num_palette;
			png_get_PLTE(png_ptr, info_ptr, &palette, &num_palette);
			if (num_palette)
				surface->clut.data=new gRGB[num_palette];
			else
				surface->clut.data=0;
			surface->clut.colors=num_palette;
			
			for (int i=0; i<num_palette; i++)
			{
				surface->clut.data[i].a=0;
				surface->clut.data[i].r=palette[i].red;
				surface->clut.data[i].g=palette[i].green;
				surface->clut.data[i].b=palette[i].blue;
			}
			if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS))
			{
				png_byte *trans;
				png_get_tRNS(png_ptr, info_ptr, &trans, &num_palette, 0);
				for (int i=0; i<num_palette; i++)
					surface->clut.data[i].a=255-trans[i];
			}
		} else
		{
			surface->clut.data=0;
			surface->clut.colors=0;
		}
		surface->clut.start=0;
		png_read_end(png_ptr, end_info);
	}
	else if (color_type == PNG_COLOR_TYPE_RGB_ALPHA && bit_depth == 8)
	{
		surface=new gSurface(width, height, bit_depth*4);
		int pass;
		png_bytep *rowptr=new png_bytep[height];


		//png_set_swap_alpha(png_ptr);

		if (color_type & PNG_COLOR_MASK_COLOR)
			png_set_bgr(png_ptr);



		int number_passes = png_set_interlace_handling(png_ptr);

		for (unsigned int i=0; i<height; i++)
			rowptr[i]=((png_byte*)(surface->data))+i*surface->stride;

		for (pass = 0; pass < number_passes; pass++)
		{
			for (int y = 0; y < height; y++)
			{
				png_read_rows(png_ptr, &rowptr[y], NULL, 1);
			}
		}
		for (int y = 0; y < height; y++)
		{
			unsigned int col;	
			unsigned int *ptr = (unsigned int *)rowptr[y];
			for(int i = 0 ; i < width ; i ++){
				col= ptr[i];
				col ^=0xFF000000;
				ptr[i] = col;
			}
		}
 
		surface->clut.data=0;
		surface->clut.colors=0;
		surface->clut.start=0; 
		delete [] rowptr;
		png_read_end(png_ptr, end_info);

	} else {
		surface=NULL;
		printf("[PNG LOAD FAILED] %s: %dx%dx%d png, %d\n", filename, (int)width, (int)height, (int)bit_depth, color_type);
	}

	png_destroy_read_struct(&png_ptr, &info_ptr,&end_info);
	fclose(fp);
	return surface;
}

void uPNG::blit(unsigned char* dest, int posX, int posY, int width, int height, int bpp, int flag)
{
	int blit_x = posX;
	int blit_y = posY;
	int blit_width = ( posX + m_surface->x> width )? width - posX : m_surface->x;
	int blit_height = ( posY + m_surface->y> height ) ? height - posY: m_surface->y;
	int dest_bypp = bpp/8;
	int dest_stride = width * dest_bypp;
//	printf("source size: %d %d\n", m_surface->x, m_surface->y);
//	printf("%d %d %d %d\n", blit_x, blit_y, blit_width, blit_height);
	if ((bpp == 8) && (m_surface->bpp==8)) 
	{
		unsigned char *srcptr=(unsigned char*)m_surface->data;
		unsigned char *dstptr=dest;
		unsigned char *nomptr = new unsigned char[blit_width];
		unsigned char gray_max = 0;
		unsigned char gray_min = 255;
		unsigned char index = 0;
		unsigned char gray_value = 0;
		gRGB pixdata;
		dstptr+=blit_x*dest_bypp+blit_y*dest_stride;
		if(m_surface->clut.colors != 0)
		{
			for (int y=0; y<blit_height; y++)
			{
				for(int x=0;x<blit_width;x++)
				{
					index = (unsigned char)(*(srcptr+x+y*m_surface->stride));
					pixdata = m_surface->clut.data[index];
					gray_value = ((pixdata.r+pixdata.g +pixdata.b)/3);
					if(gray_value > gray_max)
						gray_max = gray_value;
					if(gray_value < gray_min)
						gray_min = gray_value;
				}
			}
		}
		for (int y=0; y<blit_height; y++)
		{
			if(m_surface->clut.colors != 0)
			{
				for(int x=0;x<blit_width;x++)
				{
					pixdata = m_surface->clut.data[*(srcptr+x)];
					gray_value = ((pixdata.r+pixdata.g +pixdata.b)/3);
					if(gray_max==gray_min)
						*(nomptr+x)=gray_value;
					else
						*(nomptr+x)=( ((gray_value - gray_min)*255)/(gray_max-gray_min) );
				}
			}
			else
			{
				for(int x=0;x<blit_width;x++)
				{
					*(nomptr+x)=*(srcptr+x);
				}
			}
			if (flag & (blitAlphaTest|blitAlphaBlend))
			{
				int width=blit_width;
				unsigned char *src=(unsigned char*)nomptr;
				unsigned char *dst=(unsigned char*)dstptr;
				while (width--)
				{
					if (!*src)
					{
						src++;
						dst++;
					} else
						*dst++=*src++;
				}
			} else
				memcpy(dstptr, nomptr, blit_width*dest_bypp);
			srcptr+=m_surface->stride;
			dstptr+= dest_stride;
		}
		delete [] nomptr;
	}
	else
		printf("cannot blit %dbpp from %dbpp", bpp, m_surface->bpp);
}
int uPNG::render(const char* filename, int posX, int posY, unsigned char* dest, int width, int height, int bpp, int flag)
{
	m_surface = loadPNG(filename);
	if (m_surface == NULL)
		return -1;
	blit(dest, posX, posY, width, height, bpp, flag);
	return 0;
}

