#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string>
#include <signal.h>

#include "vuModel.h"
#include "vfd.h"

int stopReq = 0;

void sigHandler(int signo)
{
	stopReq = 1;
}

void waitSig()
{
	signal(SIGINT, sigHandler);
	while(!stopReq)
	{
		sleep(1);
	}
}

void usage(vuModel model)
{
	
	std::string message = "Usage: displayvfd [option] arg .. &\n";
	message += "Display stop : killall displayvfd\n";
	message += "Options : \n";
	switch(model)
	{
		case VUDUO:
		case VUUNO:
		case VUSOLO2:
			message += "	-t : display text to vfd, ex) -t \"test VFD!\"";
			break;
		case VUDUO2:
		case VUULTIMO:
			message += "	-t [TEXT] -f [FONT] -s [SIZE] -i [posX] -j [posY]\n";
			message += "	-p [PNG_FILE_PATH] -x [posX] -y [posY]\n";
			message += "\tex) displayvfd -t \"test VFD\" -p \"./testfont.ttf\" -s 10 -i 5 -j 5\n";
			message += "\tex) displayvfd -p \"./test.png\" -x 10 -y 10\n";
			break;
		case UNKNOWN:
			printf("Unknown model !\n");
			return;
	}
	printf("%s\n",message.c_str());
}

int main(int argc, char **argv) {

//	vuplusModel vuplusmodel = vuplusModel("./vumodel");
	vuplusModel vuplusmodel = vuplusModel();
	vuModel model = vuplusmodel.getModel();
	std::string text, fontFile, pngFilePath;
	int textPosX ,textPosY ,fontSize,pngPosX, pngPosY, opt;

	fontFile = "/usr/share/fonts/nmsbd.ttf";
	fontSize	= 14;
	textPosX = 0;
	textPosY = 0;
	pngPosX	= 0;
	pngPosY	= 0;
	opterr	= 0;

	if (argc == 1)
	{
		usage(model); return 0; 
	}

	while( ( opt = getopt( argc, argv, "t:i:j:f:s:p:x:y:")) != -1 )
	{
		switch(opt)
		{
			case 't':
				text = optarg; break;
			case 'i':
				textPosX = atoi(optarg); break;
			case 'j':
				textPosY = atoi(optarg); break;
			case 'f':
				fontFile = optarg; break;
			case 's':
				fontSize = atoi(optarg); break;
			case 'p':
				pngFilePath = optarg; break;
			case 'x':
				pngPosX = atoi(optarg); break;
			case 'y':
				pngPosY = atoi(optarg); break;
			default:
				usage(model); return 0; break;
		}
	}

	if( model == VUDUO || model == VUUNO || model == VUSOLO2 )
	{
		int res;
		textVFD *vfd;
		vfd = new textVFD();
		res = vfd->textUpdate(text);
		delete vfd;
		return 0;
	}

	if( model == VUULTIMO )
	{
		int res = -1;
		graphicVFD * vfd;
		vfd = new graphicVFD(256, 64, 8);
		if (text.size() != 0)
		{
			res = vfd->displayText(text.c_str(), fontFile.c_str(), fontSize, textPosX, textPosY);
		}
		else if (pngFilePath.size() != 0)
		{
			res = vfd->displayPNG(pngFilePath.c_str(), pngPosX, pngPosY);
		}
		delete vfd;
		return 0;
	}
	else if( model == VUDUO2 )
	{
		int res = -1;
		graphicVFD * vfd;
		vfd = new graphicVFD(140, 32, 8);
		if (text.size() != 0)
		{
			res = vfd->displayText(text.c_str(), fontFile.c_str(), fontSize, textPosX, textPosY);
		}
		else if (pngFilePath.size() != 0)
		{
			res = vfd->displayPNG(pngFilePath.c_str(), pngPosX, pngPosY);
		}
		delete vfd;
		return 0;
	}
	return 0;

}


