#include <stdio.h>

#include "ft.h"

FreeType::FreeType()
{
	Init();
}

FreeType::~FreeType()
{
	FT_Done_Face(m_face);
	FT_Done_FreeType(m_library);
}

int FreeType::Init()
{
	FT_Error error;
	error = FT_Init_FreeType( &m_library );
	if ( error ) 
	{
		printf("Error library initialization.\n");
		return -1;
	}
}

int FreeType::setFont(const char* fontPath, int fontSize, int hRes, int vRes)
{
	FT_Error error;
	error = FT_New_Face( m_library, fontPath, 0, &m_face);
	if ( error == FT_Err_Unknown_File_Format )
	{
		printf("Error, maybe font format is unsupported\n");
		return -1;
	}
	else if ( error )
	{
		printf("Error, font file could not be opened or read, or simply that it is broken\n");
		return -1;
	}

	int _fontSize = fontSize * 64;
	if(_fontSize > 0xFFFF) {
		_fontSize = 0xFFFF;
	}
	
	error = FT_Set_Char_Size(
			m_face,    /* handle to face object           */
			_fontSize,       /* char_width in 1/64th of points  */
			_fontSize,   /* char_height in 1/64th of points */
			0,     /* horizontal device resolution    */
			0 );   /* vertical device resolution      */
	if ( error )
	{
		printf("Error, set Char Size.\n");
		return -1;
	}
	return 0;
}

int FreeType::render(const char* text, const char* fontPath, int fontSize, int posX, int posY, unsigned char* dest, int dWidth, int dHeight)
{
	if (setFont(fontPath, fontSize, dWidth, dHeight) == -1)
		return -1;
//	printf("render %s %s %d %d %d %d %d\n",text, fontPath,posX, posY, dWidth, dHeight);
	FT_Error error;
	FT_GlyphSlot slot;
	FT_Bitmap *bitmap;
	FT_Int maxX;
	FT_Int maxY;
	FT_Int offsetX;
	FT_Int offsetY;
	FT_Int x,y,p,q;
	int num_chars;
	int _posX = posX;
	int _posY = posY;
	int startX =_posX;
	int startY = _posY;
	int char_distance = 0;
	int outRange = 0;

	num_chars = strlen( text );
	slot = m_face->glyph;
	for(int n=0; n < num_chars; n++)
	{
		error = FT_Load_Char( m_face, text[n], FT_LOAD_RENDER );
		if ( error ){
			printf("Error load char %c\n", text[n]);
			continue;
		}
		bitmap = &slot->bitmap;
		offsetY = ((m_face->size->metrics.height >> 6) - m_face->glyph->bitmap_top);
		maxX = _posX + bitmap->width ;
		maxY = _posY + bitmap->rows + offsetY;

		if( n != 0)
		{
			if( maxX > dWidth )
			{
				_posX = posX;
				_posY += fontSize;
				maxX = _posX + bitmap->width;
				maxY = _posY + bitmap->rows + offsetY;
			}
			if( _posY >= dHeight ){
				break;
			}
		}

		startX = _posX + slot->bitmap_left;
		startY = _posY + offsetY;
#if 0
		for ( int a = 0; a < bitmap->rows; a++){
			for( int b = 0; b < bitmap->width; b++)
				putchar ( bitmap->buffer[a*bitmap->width + b] == 0 ? ' ' : bitmap->buffer[a*bitmap->width + b] < 128 ? '+' : '*' );
			putchar('\n');
		}
#endif
		for ( x = startX, p = 0; x < maxX; x++, p++ )
		{
			for ( y = startY, q = 0; y < maxY; y++, q++ )
			{
				if ( x < 0 || y < 0 || x >= dWidth || y >= dHeight )
				{
					outRange = 1;
					continue;
				}
				dest[x + dWidth*y] |= bitmap->buffer[q * bitmap->width + p];
			}
		}
		_posX += (slot->advance.x >> 6) + char_distance;
	}
	return 0;
}

