
#ifndef _FT_H_
#define _FT_H_

#include <string>

#include <ft2build.h>
#include FT_FREETYPE_H

class FreeType
{
public:
	FreeType();
	~FreeType();
	int Init();
	int setFont(const char* fontPath, int fontSize, int hRes, int vRes);
	int render(const char* text, const char* fontPath, int fontSize, int posX, int posY, unsigned char* dest, int dWidth, int dHeight);
private:
	FT_Library	m_library;		/* handle to library */
	FT_Face		m_face;		/* handle to face object */
};

#endif
