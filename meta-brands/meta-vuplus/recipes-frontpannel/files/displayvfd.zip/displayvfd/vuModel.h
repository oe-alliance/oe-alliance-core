
#ifndef _VUMODEL_H_
#define _VUMODEL_H_

typedef enum { UNKNOWN, VUDUO, VUUNO, VUULTIMO, VUSOLO2, VUDUO2, VUSOLO4K }vuModel;

class vuplusModel
{
private:
	vuModel m_model;

public:
	vuplusModel(const char* vumodelPath = "/proc/stb/info/vumodel");
	vuModel update(const char* vumodelPath);
	inline vuModel getModel(void)
	{
		return m_model;
	}
};

#endif
