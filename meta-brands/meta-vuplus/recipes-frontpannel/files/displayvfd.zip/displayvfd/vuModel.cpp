#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "vuModel.h"

vuplusModel::vuplusModel(const char* vumodelPath):m_model(UNKNOWN)
{
	m_model = update(vumodelPath);
}

vuModel vuplusModel::update(const char* vumodelPath)
{
	char buffer[255];
	int fd = open(vumodelPath, O_RDONLY);
	if(fd == -1)
	{
		return UNKNOWN;
	}
	int rd = read(fd, buffer, 255);
	close(fd);
	if (!strncmp(buffer, "duo2", 4))
		return VUDUO2;
	else if (!strncmp(buffer, "solo2", 5))
		return VUSOLO2;
	else if (!strncmp(buffer, "ultimo", 6))
		return VUULTIMO;
	else if (!strncmp(buffer, "uno", 3))
		return VUUNO;
	else if (!strncmp(buffer, "duo", 3))
		return VUDUO;
	else if (!strncmp(buffer, "solo4k", 6))
		return VUSOLO4K;
	else
		return UNKNOWN;
	
}
