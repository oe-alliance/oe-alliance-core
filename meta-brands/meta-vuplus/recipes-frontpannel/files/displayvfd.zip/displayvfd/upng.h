
#ifndef _UPNG_H_
#define _UPNG_H_

#define PNG_SKIP_SETJMP_CHECK
#include <png.h>

struct gRGB
{
	unsigned char b, g, r, a;
	gRGB(int r, int g, int b, int a=0): b(b), g(g), r(r), a(a)
	{
	}
	gRGB(): b(0), g(0), r(0), a(0)
	{
	}
};

struct gPalette
{
	int start, colors;
	gRGB *data;
};

struct gSurface
{
	int x, y, bpp, bypp, stride;
	gPalette clut;
	
	void *data;
	int offset; // only for backbuffers

	gSurface();
	gSurface(int width, int height, int _bpp);
	~gSurface();
};

class uPNG
{
public:
	enum
	{
		blitAlphaTest=1,
		blitAlphaBlend=2,
		blitScale=4
	};
	uPNG();
	~uPNG();
	gSurface* loadPNG(const char* filename);
	void blit(unsigned char* dest, int posX, int posY, int width, int height, int bpp, int flag);
	int render(const char* filename, int posX, int posY, unsigned char* dest, int width, int height, int bpp, int flag = blitAlphaTest);
	
private:
	gSurface *m_surface;
};

#endif