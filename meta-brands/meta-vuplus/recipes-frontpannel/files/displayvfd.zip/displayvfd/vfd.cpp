#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>

#include "vfd.h"

VFD::VFD():m_fd(-1)
{
	m_fd = open("/dev/dbox/oled0", O_RDWR);
}

VFD::~VFD()
{
	if (m_fd >= 0)
	{
		close(m_fd);
		m_fd = -1;
	}
}

textVFD::textVFD()
{
	
}

textVFD::~textVFD()
{
	
}

int textVFD::textUpdate(const std::string &in)
{
	if( m_fd >= 0 )
	{
		int ret;
		std::string text = in;
		text = replace_all(text, "\n", " ");
		ret = write(m_fd, text.c_str(), text.size());
		if ( ret <= 0 )
		{
			printf("Error text update\n");
			return -1;
		}
		return 0;
	}
	return -1;
}

std::string textVFD::replace_all(const std::string &text, const std::string &s, const std::string &f)
{
	std::string::size_type found = 0;
	std::string outtext = text;
	while( (found = outtext.find(s , found)) != std::string::npos )
	{
		outtext.replace( found, s.size(), f);
	}
	return outtext;
}

graphicVFD::graphicVFD(int xres, int yres, int bpp)
{
	m_xres = xres;
	m_yres = yres;
	m_bpp = bpp;
	int buffSize = xres * yres * bpp/8;
	m_dest = new unsigned char[buffSize];
	memset(m_dest, 0, buffSize);
}

graphicVFD::~graphicVFD()
{
	delete [] m_dest;
}

int graphicVFD::displayText(const char* text, const char* fontFile, int fontSize, int posX, int posY)
{
	int res;
	res = m_ft.render( text, fontFile, fontSize, posX, posY, m_dest, m_xres, m_yres);
	if(res == 0)
		Write();
	return res;
}

void graphicVFD::Write()
{
	write(m_fd, m_dest, m_xres* m_yres);
}

/*
void graphicVFD::showBuffer()
{
	int i, j;
	for (i = 0; i < m_yres; i++ )
	{
		for( j = 0; j < m_xres; j++ )
			putchar ( m_dest[i*m_xres + j] == 0 ? ' ' : m_dest[i*m_xres + j] < 128 ? '+' : '*' );
		putchar( '\n' );
	}

}
*/

int graphicVFD::displayPNG(const char* filepath, int posX, int posY)
{
	int res;
	res = m_png.render( filepath, posX, posY, m_dest, m_xres, m_yres, m_bpp);
	if(res == 0)
		Write();
	return res;
}

