#!/usr/bin/python

import glob
import os

BP3_PART_MOUNTPOINT = '/tmp/'
BP3_BIN_NAME = 'bp3.bin'
PWD = os.environ['PWD']
NEW_BP3_PATH = PWD+'/'+BP3_BIN_NAME
BP3_INST_PRE_PATH = '/usr/local/bp3/'
BP3_INST_PATH = BP3_INST_PRE_PATH+BP3_BIN_NAME
BP3_LINK_PATH = '/'+BP3_BIN_NAME
DEBUG_ENABLE = False

def bp3Log(s):
	if DEBUG_ENABLE:
		print s

def runCmd(cmd):
	bp3Log("CMD : %s" % cmd)
	ret = os.system(cmd)
	return ret

def runPopen(cmd):
	bp3Log("CMD : %s" % cmd)
	data = os.popen(cmd).read()
	return data

def isExist(f):
	return os.access(f, os.F_OK)

def isLink(f):
	return os.path.islink(f)

class bp3Partition:
	def __init__(self, part_name = None):
		self.partName = part_name
		self.bp3 = None
		self.part = None
		self.prepare()

	def info(self):
		data = "[%s] bp3 : %s, part : %s, mounted : %s, bp3bin : %s" % (self.partName, self.bp3, self.part, self.isMount(), self.hasBp3Bin())
		bp3Log(data)

	def prepare(self):
		self.findBp3()

		if not self.doMount():
			self.bp3Mkfs()
		else:
			self.doUmount()
			self.bp3Fsck()

		self.doMount()

	def hasBp3Bin(self):
		return self.isMount() and os.access("%s/%s" % (self.getMountPoint(), BP3_BIN_NAME), os.F_OK)

	def getMountPoint(self):
		return BP3_PART_MOUNTPOINT + self.partName

	def findBp3(self):
		self.bp3 = None
		self.part = None
		devs = glob.glob("/dev/mmcblk?")
		if devs:
			for x in devs:
				data = runPopen("sgdisk -p %s" % x)
				for x in data.splitlines():
					if self.partName in x:
						self.bp3 = x.split()[0].strip()
						self.part = runPopen("ls /dev/mmcblk*p%s" % self.bp3).strip('\n')
						return				

	def bp3Mkfs(self):
		runCmd("mke2fs %s > /dev/null 2>&1" % self.part)
		runCmd("tune2fs -m 0 %s > /dev/null 2>&1" % self.part)
		self.doMount()

	def isMount(self):
		return os.path.ismount(self.getMountPoint())

	def doUmount(self):
		if self.isMount():
			runCmd("umount %s" % (self.part))
			return not self.isMount()

	def doMount(self):
		if not self.isMount():
			runCmd("mkdir -p %s" % self.getMountPoint())
			runCmd("mount %s %s > /dev/null 2>&1" % (self.part, self.getMountPoint()))

		return self.isMount()

	def bp3Fsck(self):
		runCmd("sync")
		return runCmd("e2fsck -y %s > /dev/null 2>&1" % self.part) == 0

def bp3Main():
	bp30 = bp3Partition("bp30")
	bp31 = bp3Partition("bp31")
	bp30.info()
	bp31.info()
	bp30_mp = bp30.getMountPoint()
	bp31_mp = bp31.getMountPoint()
	
	# bp30 exist check
	if bp30.bp3 is None:
		return

	# update new bp30.bin
	if isExist(NEW_BP3_PATH) and not isLink(NEW_BP3_PATH):
		runCmd("cp %s %s" % (NEW_BP3_PATH, bp30_mp))
		runCmd("cp %s %s" % (NEW_BP3_PATH, bp31_mp))
		runCmd("mv %s %s" % (NEW_BP3_PATH, BP3_INST_PATH))

	# restore each other
	else:
		if not bp30.hasBp3Bin() and bp31.hasBp3Bin():
			runCmd("cp %s/%s %s" % (bp31_mp, BP3_BIN_NAME, bp30_mp))
		elif bp30.hasBp3Bin() and not bp31.hasBp3Bin():
			runCmd("cp %s/%s %s" % (bp30_mp, BP3_BIN_NAME, bp31_mp))
		elif not bp30.hasBp3Bin() and not bp31.hasBp3Bin():
			if isExist(BP3_INST_PATH):
				runCmd("cp %s %s" % (BP3_INST_PATH, bp30_mp))
				runCmd("cp %s %s" % (BP3_INST_PATH, bp31_mp))
			else:
				print "Warning!!!!!!!!! lost b3data!"

	# link bp30.bin
	if not isExist(BP3_INST_PRE_PATH):
		runCmd("mkdir -p %s" % BP3_INST_PRE_PATH)

	if not isExist(BP3_INST_PATH):
		if bp30.hasBp3Bin():
			runCmd("cp %s/%s %s" % (bp30_mp, BP3_BIN_NAME, BP3_INST_PATH))
		elif bp31.hasBp3Bin():
			runCmd("cp %s/%s %s" % (bp31_mp, BP3_BIN_NAME, BP3_INST_PATH))

	if isExist(BP3_LINK_PATH):
		if not isLink(BP3_LINK_PATH):
			if not isExist(BP3_INST_PATH):
				runCmd("cp %s %s" % (BP3_LINK_PATH, bp30_mp))
				runCmd("cp %s %s" % (BP3_LINK_PATH, bp31_mp))
				runCmd("mv %s %s" % (BP3_LINK_PATH, BP3_INST_PATH))
			else:
				runCmd("rm %s" % BP3_LINK_PATH)
		elif os.path.realpath(BP3_LINK_PATH) != BP3_INST_PATH:
			runCmd("rm %s" % BP3_LINK_PATH)

	if not isExist(BP3_LINK_PATH) and isExist(BP3_INST_PATH):
		runCmd("ln -sf %s %s" % (BP3_INST_PATH, BP3_LINK_PATH))

	bp30.doUmount()
	bp31.doUmount()
	runCmd("sync")

if __name__ == "__main__":
	bp3Main()

