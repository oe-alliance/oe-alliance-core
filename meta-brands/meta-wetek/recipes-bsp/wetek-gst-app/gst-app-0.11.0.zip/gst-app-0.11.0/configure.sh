./configure --target=arm-buildroot-linux-gnueabi --host=arm-buildroot-linux-gnueabi --build=x86_64-unknown-linux-gnu --prefix=/usr --exec-prefix=/usr --sysconfdir=/etc --program-prefix=""  
