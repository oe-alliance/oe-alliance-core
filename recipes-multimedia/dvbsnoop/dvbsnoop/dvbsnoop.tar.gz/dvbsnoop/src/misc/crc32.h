/*
$Id: crc32.h,v 1.2 2006/01/02 18:24:04 rasc Exp $


 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)


 -- Code Module CRC32  taken von linuxtv.org

*/



#ifndef __CRC32_H
#define __CRC32_H


u_long crc32 (char *data, int len);


#endif

