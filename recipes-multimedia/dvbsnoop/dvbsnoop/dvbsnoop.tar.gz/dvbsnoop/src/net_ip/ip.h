/*
$Id: ip.h,v 1.1 2006/09/04 15:26:48 rasc Exp $


 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)


*/


#ifndef _IP_H
#define _IP_H


void net_IP_data (int v, u_char *b, int len);


#endif


