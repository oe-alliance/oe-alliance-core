/*
$Id: datagram.h,v 1.6 2006/01/02 18:23:47 rasc Exp $


 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)


*/


#ifndef _DATAGRAM_H
#define _DATAGRAM_H


void section_DSMCC_DATAGRAM (u_char *b, int len);


#endif


