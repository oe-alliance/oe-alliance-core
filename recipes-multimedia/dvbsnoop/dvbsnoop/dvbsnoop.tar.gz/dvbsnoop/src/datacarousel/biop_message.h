/*
$Id: biop_message.h,v 1.1 2006/03/06 00:04:49 rasc Exp $


 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)


*/


#ifndef _BIOP_MESSAGE
#define _BIOP_MESSAGE


u_long  BIOP_Message (int v, u_char *b);


#endif


