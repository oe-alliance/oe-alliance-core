/*

 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)

*/


#ifndef __LLC_SNAP
#define __LLC_SNAP 1

int  llc_snap (int verbosity, u_char *buf);

#endif

