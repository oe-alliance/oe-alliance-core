/*
$Id: dsmcc_unm_dsi.h,v 1.2 2006/01/02 18:23:47 rasc Exp $


 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)


*/


#ifndef __DSMCC_UNM_DSI_H
#define __DSMCC_UNM_DSI_H


int dsmcc_DownloadServerInitiate (int v, u_char *b, u_int len);


#endif



