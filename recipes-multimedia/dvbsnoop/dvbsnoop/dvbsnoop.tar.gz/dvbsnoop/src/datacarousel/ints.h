/*
$Id: ints.h,v 1.8 2006/01/02 18:23:47 rasc Exp $


 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)


*/


#ifndef __INTS_H
#define __INTS_H


void  section_DSMCC_INT (u_char *b, int len);


#endif



