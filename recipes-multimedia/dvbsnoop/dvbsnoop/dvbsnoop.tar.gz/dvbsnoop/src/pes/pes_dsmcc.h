/*

 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)



*/

#ifndef __PES_DSMCC_H__
#define __PES_DSMCC_H__

void  PES_decodeDSMCC (u_char *b, int len);


#endif

