/*

 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)



*/

#ifndef __PES_PSDIR_H__
#define __PES_PSDIR_H__

void  PES_decodePSDIR (u_char *b, int len);

#endif

