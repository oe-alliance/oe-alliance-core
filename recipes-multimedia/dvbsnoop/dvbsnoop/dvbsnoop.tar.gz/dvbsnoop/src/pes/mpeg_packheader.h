/*
$Id: mpeg_packheader.h,v 1.2 2006/01/02 18:24:12 rasc Exp $

   
 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)



*/

#ifndef __MPEG_PACK_HEADER__
#define __MPEG_PACK_HEADER__


void mpeg_pack_header (int v, u_char *b, int len);


#endif

