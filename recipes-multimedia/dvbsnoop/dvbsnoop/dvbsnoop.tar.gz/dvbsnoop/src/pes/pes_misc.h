/*
$Id: pes_misc.h,v 1.4 2006/01/02 18:24:12 rasc Exp $

   
 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)



*/

#ifndef __PES_MISC_H__
#define __PES_MISC_H__


void print_xTS_field (int v, const char *str, u_char *b, int bit_offset);


#endif

