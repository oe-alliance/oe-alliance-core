/*
$Id: tdt.h,v 1.6 2006/01/02 18:24:25 rasc Exp $

 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)



*/



#ifndef __TDT_H
#define __TDT_H 


void section_TDT (u_char *b, int len);


#endif

