/*
$Id: eit.h,v 1.5 2006/01/02 18:24:24 rasc Exp $

 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)



*/



void section_EIT (u_char *b, int len);

