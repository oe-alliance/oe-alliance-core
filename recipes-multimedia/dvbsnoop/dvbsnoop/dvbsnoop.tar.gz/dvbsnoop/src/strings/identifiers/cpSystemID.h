{ 0x0100, 0x0100, "Digital Transmission Licensing Administrator, LLC" },
{ 0x0101, 0x0101, "Digital Content Protection, LLC" },
{ 0, 0, NULL }
