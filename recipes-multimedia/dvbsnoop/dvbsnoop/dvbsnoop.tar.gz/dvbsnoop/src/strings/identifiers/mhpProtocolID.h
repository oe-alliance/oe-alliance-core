{ 0x0000, 0x0000, "reserved_future_use" },
{ 0x0001, 0x0001, "MHP Object Carousel as defined in annex B, \"(normative): Object Carousel\" on Page 295 of V1.1.1" },
{ 0x0002, 0x0002, "IP via DVB multiprotocol encapsulation as defined in ETSI EN 301 192, ETSI TR 101 202" },
{ 0x0003, 0x0003, "Transport via HTTP over the interaction channel" },
{ 0x0004, 0x00FF, "Reserved for use by DVB" },
{ 0x0100, 0xFFFF, "[subject to registration by DVB]" },
{ 0, 0, NULL }
