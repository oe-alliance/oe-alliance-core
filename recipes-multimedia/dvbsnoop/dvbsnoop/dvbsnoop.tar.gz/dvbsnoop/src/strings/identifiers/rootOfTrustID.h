{ 0x0000, 0x0001, "Reserved | DVB" },
{ 0x0002, 0x0002, "Content Management License Administrator (CMLA) | CLMA" },
{ 0, 0, NULL }
