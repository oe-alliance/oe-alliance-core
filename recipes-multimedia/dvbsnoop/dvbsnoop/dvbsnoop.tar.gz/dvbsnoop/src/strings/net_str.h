/*
$Id: net_str.h,v 1.1 2006/09/07 13:39:12 rasc Exp $ 


 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de


 -- Network strings  (IP, UDP, ICMP)




$Log: net_str.h,v $
Revision 1.1  2006/09/07 13:39:12  rasc
net string module



*/


#ifndef __NET_STR_H
#define __NET_STR_H 


char *netStr_RFC790_protocol_nr (u_int i);





#endif




