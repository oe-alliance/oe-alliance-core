
Private Data Decoding
=====================

Here is a place to provide code and structures
for decoding of private/userdef section tables or descriptors.

If you know section or descriptor strcutures of "private"
protocols or provider defined structures, please let the
author know.


Please check for legal issues, when using provider specific
data structures in your own software!
Using  these data structures may require a certification or
licensing process by the provider.


