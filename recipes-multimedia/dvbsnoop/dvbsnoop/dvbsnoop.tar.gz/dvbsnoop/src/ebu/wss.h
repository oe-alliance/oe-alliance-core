/*
$Id: wss.h,v 1.2 2006/01/02 18:24:04 rasc Exp $


 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)


 -- misc routines for EBU  WSS (Wide Screen Signalling)



*/

#ifndef _WSS_H_
#define _WSS_H_


void print_wss_decode (int v, u_char *b);


#endif


