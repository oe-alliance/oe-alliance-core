/*
$Id: dmx_pes.h,v 1.6 2006/01/02 18:23:58 rasc Exp $


 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)


*/


#ifndef __DMX_PES_H
#define __DMX_PES_H


int  doReadPES (OPTION *opt);


#endif



