/*
$Id: dmx_error.h,v 1.4 2005/12/27 23:30:27 rasc Exp $


 DVBSNOOP

 a dvb sniffer  and mpeg2 stream analyzer tool
 http://dvbsnoop.sourceforge.net/

 (c) 2001-2006   Rainer.Scherg@gmx.de (rasc)

*/

#ifndef __DMX_ERROR_H
#define __DMX_ERROR_H


int  IO_error (char *str);


#endif


