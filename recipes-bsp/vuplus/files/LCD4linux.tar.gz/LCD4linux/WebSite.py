# -*- coding: utf-8 -*-
from twisted.web import resource, http
import os
########################################################
class LCD4linuxweb(resource.Resource):
    
	title = "LCD4Linux Webinterface"
 	isLeaf = False
   
	def render(self, req):
		req.setHeader('Content-type', 'text/html')
		req.setHeader('charset', 'UTF-8')

		""" rendering server response """
		command = req.args.get("cmd",None)
		html = "<html>"
		html += "<head>\n"
		html += "<meta http-equiv=\"Content-Language\" content=\"de\">\n"
		html += "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">\n"
		html += "<meta http-equiv=\"cache-control\" content=\"no-cache\" />\n"
		html += "<meta http-equiv=\"pragma\" content=\"no-cache\" />\n"
		html += "<meta http-equiv=\"expires\" content=\"0\">\n"
		html += "<meta http-equiv=\"refresh\" content=\"3\">\n"
		html += "<title>LCD4linux</title>\n"
		html += "</head>"
		html += "<body bgcolor=\"#000000\" text=\"#FFFFFF\">\n"
		html += "<form method=\"POST\" action=\"--WEBBOT-SELF--\">\n"
		if os.path.isfile("/tmp/dpf.png"):
			html += "<img border=\"0\" src=\"/lcd4linux/dpf.png\"> \n"
		elif os.path.isfile("/tmp/dpf.jpg"):
			html += "<img border=\"0\" src=\"/lcd4linux/dpf.jpg\"> \n"
		html += "</body>\n"
		html += "</html>\n"

		html += "</form>\n"

		return html
