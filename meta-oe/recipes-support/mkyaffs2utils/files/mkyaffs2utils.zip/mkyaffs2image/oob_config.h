/******************************************************************************
*    Copyright (c) 2009-2010 by czy.
*    All rights reserved.
* ***
*    written by CaiZhiYong. 2010-10-13 14:01:19
*
******************************************************************************/

#ifndef __OOB_CONFIG__H
#define __OOB_CONFIG__H

#define MAX_OBJECTS		40000
#define MAX_PAGESIZE		0x8000
#define OOBSIZE_FOR_YAFFS	0x20

/******************************************************************************/
extern const char *nand_controller_version;

/******************************************************************************/

/* this follow must be consistent with fastboot !!! */
enum ecc_type
{
    et_ecc_none     = 0x00,
    et_ecc_8bit     = 0x01,
    et_ecc_13bit    = 0x02,
    et_ecc_18bit    = 0x03,
    et_ecc_24bit    = 0x04,
    et_ecc_27bit    = 0x05,
    et_ecc_32bit    = 0x06,
    et_ecc_41bit    = 0x07,
    et_ecc_48bit    = 0x08,
    et_ecc_60bit    = 0x09,
    et_ecc_72bit    = 0x0a,
    et_ecc_80bit    = 0x0b,
    et_ecc_last     = 0x0c,
};
/*****************************************************************************/

enum page_type
{
    pt_pagesize_2K         = 0x01,
    pt_pagesize_4K         = 0x02,
    pt_pagesize_8K         = 0x03,
    pt_pagesize_16K        = 0x04,
    pt_pagesize_32K        = 0x05,
    pt_pagesize_last       = 0x06,
};

/*****************************************************************************/

struct nand_oob_free
{
	unsigned long offset;
	unsigned long length;
};
/*****************************************************************************/

struct oob_info
{
    unsigned int nandip;
    enum page_type pagetype;
    enum ecc_type ecctype;
    unsigned int oobsize;
    struct nand_oob_free *freeoob;
};

/*****************************************************************************/

struct oob_info * get_oob_info(enum page_type pagetype, 
    enum ecc_type ecctype);

char *get_ecctype_str(enum ecc_type ecctype);

char *get_pagesize_str(enum page_type pagetype);

unsigned int get_pagesize(enum page_type pagetype);


/******************************************************************************/
#endif /* __OOB_CONFIG__H */

