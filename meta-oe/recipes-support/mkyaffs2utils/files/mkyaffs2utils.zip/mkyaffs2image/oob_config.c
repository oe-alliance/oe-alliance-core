/******************************************************************************
*    Copyright (c) 2009-2010 by Hisi
*    All rights reserved.
* ***
*    written by Czy. 2010-10-13 14:01:24
*
******************************************************************************/

#include "oob_config.h"

/*****************************************************************************/
/* nandcv610֮�󣬰�NANDIP�ֶζ���Ϊ0x00��Ŀ����Ϊ���������ļ�ϵͳ������Բ�����
 * nandc�߼��汾�����ֺ�������nandc�汾������ʹ��ͬһ�׹��߱��������yaffs2���� 
 */

#ifdef CFG_SPI_NAND_SUPPORT
#undef NANDIP
#define	NANDIP		0x400
const char *nand_controller_version  = "Nand Controller SFCv400";
#else
#undef NANDIP
#define	NANDIP		0x610
const char *nand_controller_version  = "Nand Controller NFCv610";
#endif

/*****************************************************************************/
struct nand_oob_free oobfree_def[] =
{
    {2, 30}, {0, 0},
};
/*****************************************************************************/

static struct oob_info hinfc610_oob_info[] =
{
    {NANDIP, pt_pagesize_2K,  et_ecc_none,  32,  oobfree_def},
    {NANDIP, pt_pagesize_4K,  et_ecc_none,  32,  oobfree_def},
    {NANDIP, pt_pagesize_8K,  et_ecc_none,  32,  oobfree_def},
    {NANDIP, pt_pagesize_16K, et_ecc_none,  32,  oobfree_def},
    {NANDIP, pt_pagesize_32K, et_ecc_none,  32,  oobfree_def},

    {0},
};
/*****************************************************************************/

struct oob_info * get_oob_info(enum page_type pagetype, 
    enum ecc_type ecctype)
{
    struct oob_info *info = hinfc610_oob_info; 
    
    for (; info->freeoob; info++)
    {
        if (info->ecctype == ecctype
            && info->pagetype == pagetype)
        {
            return info;
        }
    }

    return 0;
}
/*****************************************************************************/

char *get_ecctype_str(enum ecc_type ecctype)
{
    char *ecctype_str[et_ecc_last+1] = { (char *)"None", (char *)"8bit", 
        (char *)"13bit", (char *)"18bit", (char *)"24bits", 
        (char *)"27bit", (char *)"32bit", (char *)"41bit", 
        (char *)"48bit", (char *)"60bit", (char *)"72bit", 
        (char *)"80bit"};
    if (ecctype < et_ecc_none || ecctype > et_ecc_last)
    {
        ecctype = et_ecc_last;
    }
    return ecctype_str[ecctype];
}
/*****************************************************************************/

char *get_pagesize_str(enum page_type pagetype)
{
    char *pagesize_str[pt_pagesize_last+1] = {(char *)"Unknown", (char *)"2K",
        (char *)"4K", (char *)"8K", (char *)"16K", 
        (char *)"32K", (char *)"unknown" };
    if (pagetype < pt_pagesize_2K|| pagetype > pt_pagesize_last)
    {
        pagetype = pt_pagesize_last;
    }
    return pagesize_str[pagetype];
}
/*****************************************************************************/

unsigned int get_pagesize(enum page_type pagetype)
{
    unsigned int pagesize[] = {0, 2048, 4096, 8192, 16384, 32768, 0};
    return pagesize[pagetype];
}
