#include <sys/types.h>
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/un.h>
#include <string.h>
#include <dirent.h>

#define NAME "/tmp/egami.socket"
#define CMD_START_CAMD			"START_CAMD"
#define CMD_STOP_CAMD			"STOP_CAMD"
#define CMD_NEW_CAMD			"NEW_CAMD"

const char* info = "emud version "VERSION" by EGAMI Team at "__DATE__ " "__TIME__" \n";

void processMessage(char *inData);

int is_running()
{
	struct dirent *entry;
	int val=0;
	char *name;
	char buf[1024], cmdline[40];
	FILE *fp;
	DIR *dir;

	dir= opendir("/proc");
	if(dir)
	{
		while(entry = readdir(dir))
		{
			name = entry->d_name;

			if (!(*name >= '0' && *name <= '9'))
				continue;

			sprintf(cmdline, "/proc/%s/cmdline", name);
			if ((fp = fopen(cmdline, "r")) == NULL)
				continue;
			if ((fread(buf, 1, sizeof(buf) - 1, fp)) > 0)
				if (strstr(buf, "emud") != 0)
					val +=1;
			fclose(fp);
		}
		closedir(dir);
	}
	return val;
}

int main()
{
	printf("[EGAMI-EMUD] %s", info);
	
	if(is_running()>1)
	{
		printf("[EGAMI-EMUD] Only one instance");
		return -1;
	}

	int sock, msgsock, rval, rc;
	struct sockaddr_un server;
	char buf[256];

	rc = system("rm -rf /tmp/egami.socket");
	
	sock = socket(AF_UNIX, SOCK_STREAM, 0);
	if (sock < 0) {
		perror("opening stream socket");
		exit(1);
	}
	server.sun_family = AF_UNIX;
	strcpy(server.sun_path, NAME);
	if (bind(sock, (struct sockaddr *) &server, sizeof(struct sockaddr_un))) {
		perror("binding stream socket");
		exit(1);
	}

//	printf("Socket has name %s\n", server.sun_path);
	listen(sock, 5);
	for (;;) {
		msgsock = accept(sock, 0, 0);
		if (msgsock == -1)
			perror("accept");
		else do {
			bzero(buf, sizeof(buf));
			if ((rval = read(msgsock, buf, 256)) < 0)
				perror("reading stream message");
			// else if (rval == 0)
				// printf("Ending connection\n");
			else
				processMessage(buf);
				//printf("-->%s\n", buf);
		} while (rval > 0);
		close(msgsock);
	}
	close(sock);
	unlink(NAME);

	return EXIT_SUCCESS;
}


void processMessage(char *inData)
{
	char *tmp;
	char command[20];
	char data[256];
	char buff[256];
	char cmd[100];
	int rc;

	buff[0] = 0;

	tmp = strchr(inData, ',');

	if (tmp)
	{
		strncpy(command, inData, tmp - inData);
		command[tmp - inData] = 0;
		strcpy(data, tmp + 1);
	}
	else
	{
		strcpy(command, inData);
		data[0] = 0;
	}

	// printf("Command='%s'\n", command);

	// Dispath out command
	rc = system("rm -f /tmp/gbox* && rm -f /tmp/*camd*.sock*  && rm -f /tmp/*beta*.sock* && rm -f /tmp/*rdgd*.sock* && rm -f /tmp/*.info && rm -f /tmp/*.cmd && rm -f /tmp/*.pid && rm -f /tmp/cainfo.txt &&  rm -f /tmp/*.ips && rm -f /tmp/*card*.sock* && rm -f /tmp/*powersock* && rm -f /tmp/share.* && rm -f gbox.* && rm -f *CCcam* && rm -f /tmp/sc.socket /tmp/ser* && rm -f /tmp/.CCcam.nodeid rm -rf /tmp/*.tmp && rm -rf /tmp/hyper* && rm -rf /tmp/gbox*");
	
	if (strcmp(command, CMD_START_CAMD) == 0) {
		rc = system("/usr/bin/StartEGCam stop");
		rc = system("/usr/bin/StartEGCam start");
	}
	else if (strcmp(command, CMD_STOP_CAMD) == 0) {
		sprintf(cmd,"%s stop",data);
		rc = system(cmd);
	}
	else if (strcmp(command, CMD_NEW_CAMD) == 0) {
		sprintf(cmd,"%s start",data);
		system(cmd);
		
	}

	
}

